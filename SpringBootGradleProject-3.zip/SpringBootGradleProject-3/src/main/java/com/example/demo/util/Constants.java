package com.example.demo.util;

public class Constants {
	
	public static final String GETBYID = "/getById/{id}";
	public static final String POST = "/createUser";
	public static final String HEALTHCHECK="/health/{id}";
	public static final String GETALLUSERS="/getAllUsers";
}
